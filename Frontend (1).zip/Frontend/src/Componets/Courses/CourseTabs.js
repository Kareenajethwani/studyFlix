import React, { useState } from "react";
import Documentation from "./Documentation";
import DocumentationContent from "./DocumentationContent";
import CoursesNavbar from "../Navbar/CoursesNavbar";
import CoursesVideotab from "./Videotab";
import ProjectTabs from "./ProjectTabs";
import NotesTabs from "./NotesTabs";
import Forum from "./Forum";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faBook,
  faComments,
  faDiagramProject,
  faNoteSticky,
  faVideo,
} from "@fortawesome/free-solid-svg-icons";

export default function CourseTabs({ selectedDocs, setselectedDocs }) {
  const [tab, settab] = useState(false);
  const [activeTab, setActiveTab] = useState("documentation");

  const handleTabClick = (tabName) => {
    setActiveTab(tabName);
  };

  return (
    <>
      <div className="bg-gray-900 text-white min-h-screen" style={{ background: '#89ABE3' }}>
        <CoursesNavbar />
        <div className="text-center text-3xl mb-10">{sessionStorage.getItem('CourseName')}</div>
        <div className="flex justify-center flex-wrap gap-4 sm:gap-8">
          <div
            style={activeTab === "documentation" ? { background: '#F0F4F8', color: '#000' } : { background: 'rgb(31 41 55 /1)', color: '#fff' }}
            className={` rounded p-4 text-center transition duration-300 ease-in-out w-32 h-32 flex flex-col items-center justify-center cursor-pointer`}
            onClick={() => handleTabClick("documentation")}
          >
            <FontAwesomeIcon icon={faBook} className="fa-2x mb-2" />
            <div className="text-md">Documentation</div>
          </div>

          <div
            style={activeTab === "video" ? { background: '#F0F4F8', color: '#000' } : { background: 'rgb(31 41 55 /1)', color: '#fff' }}
            className={`${activeTab === "video" ? "bg-gray-700" : "bg-gray-800"
              } hover:bg-gray-800 rounded p-4 text-center transition duration-300 ease-in-out w-32 h-32 flex flex-col items-center justify-center cursor-pointer`}
            onClick={() => handleTabClick("video")}
          >
            <FontAwesomeIcon icon={faVideo} className="fa-2x mb-2" />
            <div className="text-md">Video</div>
          </div>
          <div
            style={activeTab === "project" ? { background: '#F0F4F8', color: '#000' } : { background: 'rgb(31 41 55 /1)', color: '#fff' }}

            className={`${activeTab === "project" ? "bg-gray-700" : "bg-gray-800"
              } hover:bg-gray-800 rounded p-4 text-center transition duration-300 ease-in-out w-32 h-32 flex flex-col items-center justify-center cursor-pointer`}
            onClick={() => handleTabClick("project")}
          >
            <FontAwesomeIcon icon={faDiagramProject} className="fa-2x mb-2" />
            <div className="text-md">Project</div>
          </div>
          <div
            style={activeTab === "notes" ? { background: '#F0F4F8', color: '#000' } : { background: 'rgb(31 41 55 /1)', color: '#fff' }}

            className={`${activeTab === "notes" ? "bg-gray-700" : "bg-gray-800"
              } hover:bg-gray-800 rounded p-4 text-center transition duration-300 ease-in-out w-32 h-32 flex flex-col items-center justify-center cursor-pointer`}
            onClick={() => handleTabClick("notes")}
          >
            <FontAwesomeIcon icon={faNoteSticky} className="fa-2x mb-2" />
            <div className="text-md">Notes</div>
          </div>
          <div
            style={activeTab === "forum" ? { background: '#F0F4F8', color: '#000' } : { background: 'rgb(31 41 55 /1)', color: '#fff' }}

            className={`${activeTab === "forum" ? "bg-gray-700" : "bg-gray-800"
              } hover:bg-gray-800 rounded p-4 text-center transition duration-300 ease-in-out w-32 h-32 flex flex-col items-center justify-center cursor-pointer`}
            onClick={() => handleTabClick("forum")}
          >
            <FontAwesomeIcon icon={faComments} className="fa-2x mb-2" />
            <div className="text-md">Forum</div>
          </div>
        </div>

        <div className="flex justify-center space-x-4 mt-3">
          {activeTab === "documentation" ? (
            !tab ? (
              <Documentation setselectedDocs={setselectedDocs} settab={settab} />
            ) : (
              <DocumentationContent selectedDocs={selectedDocs} settab={settab} />
            )
          ) : activeTab === "video" ? (
            <CoursesVideotab />
          ) : activeTab === "project" ? (
            <ProjectTabs />
          ) : activeTab === "notes" ? (
            <NotesTabs />
          ) : activeTab === "forum" ? (
            <Forum />
          ) : (
            ""
          )}
        </div>
      </div>
    </>
  );
}
