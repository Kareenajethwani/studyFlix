import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import NotFound from "../Nopage/NotFound";
import CoursesNavbar from "../Navbar/CoursesNavbar";
import CustomCheckbox from "./CustomCheckbox";
import { Tooltip } from "@mui/material";
import { FavoriteBorder } from "@mui/icons-material";

export default function Courses() {
  const navigate = useNavigate();
  const [courses, setCourses] = useState([]);
  const [datafetched, setdatafetched] = useState(false);
  const [filteredCourses, setFilteredCourses] = useState([]);
  const [isloading, setisloading] = useState(true);
  const [filters, setFilters] = useState({
    title: [],
  });
  const checklogin = sessionStorage.getItem("userID");

  useEffect(() => {
    if (checklogin === null && window.location.pathname !== "/Auth") {
      navigate("/Auth");
    }
  }, [checklogin, navigate]);

  useEffect(() => {
    const getData = async () => {
      try {
        let res = await axios.get(
          "https://skillixbackend.glitch.me/auth/getAllCourse"
        );
        if (res.data) {
          setCourses(res.data.data);
          setFilteredCourses(res.data.data);
          setisloading(false);
          setdatafetched(true);
        }
      } catch (err) {
        setisloading(false);
      }
    };
    getData();
    sessionStorage.removeItem("CourseID");
    sessionStorage.removeItem("CourseName");
    sessionStorage.removeItem("CourseUserID");
  }, []);

  function handleFilterChange(filterType, value) {
    setisloading(true);
    const updatedFilters = { ...filters };
    if (updatedFilters[filterType].includes(value)) {
      updatedFilters[filterType] = updatedFilters[filterType].filter(
        (item) => item !== value
      );
    } else {
      updatedFilters[filterType].push(value);
    }
    setFilters(updatedFilters);
    applyFilters(updatedFilters);
    setisloading(false);
  }

  function applyFilters(updatedFilters) {
    let filteredData = [...courses];
    Object.keys(updatedFilters).forEach((filterType) => {
      if (updatedFilters[filterType].length > 0) {
        filteredData = filteredData.filter((course) =>
          updatedFilters[filterType].includes(course[filterType])
        );
      }
    });
    setFilteredCourses(filteredData);
  }

  function FilterSection({ title, filterType, options }) {
    return (
      <div>
        <div className="flex justify-between items-center mb-2 cursor-pointer">
          <span className="font-semibold">{title}</span>
        </div>
        <div className="space-y-2">
          {options.map((option) => (
            <CustomCheckbox
              key={option.value}
              filterType={filterType}
              option={option}
              isChecked={filters[filterType].includes(option.value)}
              onChange={(e) => handleFilterChange(filterType, e.target.value)}
            />
          ))}
        </div>
      </div>
    );
  }

  const uniqueTags = [];
  courses?.map((item) => {
    var findItem = uniqueTags.find((x) => x.value === item.title);
    if (!findItem) uniqueTags.push({ value: item.title, label: item.title });
    return 0;
  });

  const titleOption = uniqueTags ?? [];

  const handleFav = async (e,courseID) => {
    e.stopPropagation();
    try {
      let res = await axios.post(
        "https://skillixbackend.glitch.me/auth/addFav",
        {
          UserID: checklogin,
          CourseID: courseID,
        }
      );
      if (res.data) {
        navigate("/MyCourses");
      }
    } catch (err) {
      console.log(err);
    }
  };

  const [handleLatest, sethandleLatest] = useState(false);
  const handleLatestCreated = () => {
    sethandleLatest(!handleLatest);
    filteredCourses.reverse();
  };

  const [count, setcount] = useState(0);
  const handleLatestUpdated = () => {
    setcount(count + 1);
    count % 2
      ? filteredCourses.sort((a, b) => {
          let A = new Date(a.updatedAt);
          let B = new Date(b.updatedAt);
          return A - B;
        })
      : filteredCourses.sort((a, b) => {
          let A = new Date(a.updatedAt);
          let B = new Date(b.updatedAt);
          return B - A;
        });
  };

  return (
    <>
      <div className="bg-gray-900 text-white" style={{background:'#89ABE3'}}>
        <CoursesNavbar />
        <div className="text-center mt-8" >
          <h2 className="text-3xl bg-gray-900 text-white font-semibold" style={{background:'#89ABE3'}}>
            All Courses
          </h2>
        </div>
      </div>
      <div className="bg-gray-900 text-white min-h-screen flex" style={{background:'#89ABE3'}}>
        <div
          className="bg-gray-800 p-4 shadow rounded-lg hidden sm:block"
          style={{
            width: "25%",
            marginTop: "40px",
            marginLeft: "10px",
            height: "70vh",
            overflow: "overlay",
            background:'#2B3A67',
            color:'#D1D5DB'
          }}
        >
          <div className="flex items-center space-x-2 border-b border-gray-700 pb-4 mb-4"> 
            <i className="fas fa-bars text-gray-400"></i>
            <span className="font-semibold text-lg">Filters</span>
          </div>
          {isloading ? (
            <>
              <div className="space-y-6">
                <div className="bg-gray-500 p-2 rounded-lg animate-pulse"></div>
                <div className="bg-gray-500 p-2 rounded-lg animate-pulse"></div>
                <div className="bg-gray-500 p-2 rounded-lg animate-pulse"></div>
                <div className="bg-gray-500 p-2 rounded-lg animate-pulse"></div>
              </div>
            </>
          ) : (
            <div className="space-y-6">
              <FilterSection
                title="Filter by Course"
                filterType="title"
                options={titleOption}
              />
              <div>
                <div className="flex justify-between items-center mb-2 cursor-pointer">
                  <span className="font-semibold">{"Filter By Latest"}</span>
                </div>
                <div className="space-y-2">
                  <CustomCheckbox
                    filterType={"date"}
                    option={{ value: "Latest", label: "Latest Created" }}
                    onChange={handleLatestCreated}
                    isChecked={handleLatest}
                  />
                  <CustomCheckbox
                    filterType={"dateu"}
                    option={{ value: "LatestU", label: "Latest Updated" }}
                    onChange={handleLatestUpdated}
                    isChecked={count % 2 ? true : false}
                  />
                </div>
              </div>
            </div>
          )}
        </div>
        <div className="w-full p-4 sm:p-10">
          {datafetched && filteredCourses?.length === 0 && <NotFound />}
          {isloading && (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-8 justify-center">
                <div
                  className="home-card rounded-lg overflow-hidden shadow-lg bg-gray-800"
                  style={{ borderRadius: "20px",background:'#F0F4F8' }}
                >
                  <div style={{ height: "300px" }}>
                    <div
                      className="bg-gray-500 animate-pulse"
                      style={{ height: "150px" }}
                    >
                      {" "}
                    </div>
                    <div
                      className="flex mt-5"
                      style={{ justifyContent: "space-between" }}
                    >
                      <div
                        className="bg-gray-500 animate-pulse ml-2"
                        style={{ width: "30%", height: "20px" }}
                      >
                        {" "}
                      </div>
                      <div
                        className="bg-gray-500 animate-pulse mr-2"
                        style={{ width: "10%", height: "20px" }}
                      >
                        {" "}
                      </div>
                    </div>
                    <div
                      className="bg-gray-500 animate-pulse mt-8 ml-2 mr-2"
                      style={{ width: "96%", height: "10px" }}
                    >
                      {" "}
                    </div>
                    <div
                      className="bg-gray-500 animate-pulse mt-2 ml-2 mr-2"
                      style={{ width: "96%", height: "10px" }}
                    >
                      {" "}
                    </div>
                    <div
                      className="bg-gray-500 animate-pulse mt-2 ml-2 mr-2"
                      style={{ width: "60%", height: "10px" }}
                    >
                      {" "}
                    </div>
                  </div>
                </div>
                <div
                  className="home-card rounded-lg overflow-hidden shadow-lg bg-gray-800"
                  style={{ borderRadius: "20px",background:'#F0F4F8' }}
                >
                  <div style={{ height: "300px" }}>
                    <div
                      className="bg-gray-500 animate-pulse"
                      style={{ height: "150px" }}
                    >
                      {" "}
                    </div>
                    <div
                      className="flex mt-5"
                      style={{ justifyContent: "space-between" }}
                    >
                      <div
                        className="bg-gray-500 animate-pulse ml-2"
                        style={{ width: "30%", height: "20px" }}
                      >
                        {" "}
                      </div>
                      <div
                        className="bg-gray-500 animate-pulse mr-2"
                        style={{ width: "10%", height: "20px" }}
                      >
                        {" "}
                      </div>
                    </div>
                    <div
                      className="bg-gray-500 animate-pulse mt-8 ml-2 mr-2"
                      style={{ width: "96%", height: "10px" }}
                    >
                      {" "}
                    </div>
                    <div
                      className="bg-gray-500 animate-pulse mt-2 ml-2 mr-2"
                      style={{ width: "96%", height: "10px" }}
                    >
                      {" "}
                    </div>
                    <div
                      className="bg-gray-500 animate-pulse mt-2 ml-2 mr-2"
                      style={{ width: "60%", height: "10px" }}
                    >
                      {" "}
                    </div>
                  </div>
                </div>
                <div
                  className="home-card rounded-lg overflow-hidden shadow-lg bg-gray-800"
                  style={{ borderRadius: "20px",background:'#F0F4F8' }}
                >
                  <div style={{ height: "300px" }}>
                    <div
                      className="bg-gray-500 animate-pulse"
                      style={{ height: "150px" }}
                    >
                      {" "}
                    </div>
                    <div
                      className="flex mt-5"
                      style={{ justifyContent: "space-between" }}
                    >
                      <div
                        className="bg-gray-500 animate-pulse ml-2"
                        style={{ width: "30%", height: "20px" }}
                      >
                        {" "}
                      </div>
                      <div
                        className="bg-gray-500 animate-pulse mr-2"
                        style={{ width: "10%", height: "20px" }}
                      >
                        {" "}
                      </div>
                    </div>
                    <div
                      className="bg-gray-500 animate-pulse mt-8 ml-2 mr-2"
                      style={{ width: "96%", height: "10px" }}
                    >
                      {" "}
                    </div>
                    <div
                      className="bg-gray-500 animate-pulse mt-2 ml-2 mr-2"
                      style={{ width: "96%", height: "10px" }}
                    >
                      {" "}
                    </div>
                    <div
                      className="bg-gray-500 animate-pulse mt-2 ml-2 mr-2"
                      style={{ width: "60%", height: "10px" }}
                    >
                      {" "}
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-8 justify-center">
            {filteredCourses?.map((c) => {
              return (
                <div
                  key={c?._id}
                  className="home-card rounded-lg overflow-hidden shadow-lg bg-gray-800"
                  style={{ borderRadius: 20,background:'#F0F4F8' }}
                  onClick={() => {
                    sessionStorage.setItem("CourseID", c._id);
                    sessionStorage.setItem("CourseUserID", c.userID);
                    sessionStorage.setItem("CourseName", c.title);
                    navigate("/coursedocs");
                  }}
                >
                  <img
                    src={c?.imageLink}
                    alt="Placeholder"
                    className="w-full"
                    style={{ maxHeight: "160px" }}
                  />
                  <div className="p-4">
                    <div
                      className="flex"
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        color:'#000'
                      }}
                    >
                      <h3 className="text-lg font-semibold mb-2">
                        {c?.title}
                      </h3>

                      <Tooltip
                        title="Add To My Course"
                        onClick={(e) => handleFav(e,c?._id)}
                      >
                        <FavoriteBorder size="md" />
                      </Tooltip>
                    </div>
                    <p className="text-gray-400">
                      {c?.description?.substring(0, 150)}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}
